/**
 * 
 */
package com.capGbank.beans;

import java.util.Date;

/**
 * @author ypambi
 * 
 * create table transactions(transaction_id number,transaction_description varchar(50),
date_of_transaction DATE,transaction_type varchar(30),
transaction_amount number,account_number NUMBER,
transaction_status varchar(30),
PAYEE_ACCOUNT_ID NUMBER,PRIMARY KEY(TRANSACTION_ID),
foreign key(account_number) references Account_master(account_number),
foreign key(payee_account_id) references Account_master(account_number));
 *
 */
public class Transactions {
	
	private long transactionId;
	private String transactionDescription;
	private Date dateOfTransaction;
	private String transactionType;
	private double transactionAmount;
	private String accountNumber;
	private String transactionStatus;
	private String payeeAccountId;
	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionDescription() {
		return transactionDescription;
	}
	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public String getPayeeAccountId() {
		return payeeAccountId;
	}
	public void setPayeeAccountId(String payeeAccountId) {
		this.payeeAccountId = payeeAccountId;
	}
	

}
