/**
 * 
 */
package com.capGbank.beans;

import java.util.Date;

/**
 * @author yagni
 *
 *         Account_Number NUMBER,Account_Type VARCHAR(25), Account_balance
 *         NUMBER,Open_Date DATE,Interest_rate NUMBER, Account_Holder_Name
 *         VARCHAR(30), Email VARCHAR(30) UNIQUE,Address VARCHAR(30),pan_number
 *         varchar(30) UNIQUE,PRIMARY KEY(Account_number)
 *
 */
public class AccountMaster {
	private String accountNumber;
	private String accountType;
	private double accountBalance;
	private Date openDate;
	private double interestRate;
	private String accountHolderName;
	private String email;
	private String address;
	private String panNumber;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

}
