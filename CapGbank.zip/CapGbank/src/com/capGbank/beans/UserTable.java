/**
 * 
 */
package com.capGbank.beans;

/**
 * @author ypambi
 * 
 * 
 *         create table user_table(user_id number,login_password varchar(30),
 *         secret_question varchar(50),transaction_password
 *         varchar(30),lock_status varchar(30), account_number number,primary
 *         key(user_id),foreign key(account_number) references
 *         Account_master(account_number));
 *
 */
public class UserTable {
	private String userId;
	private String loginPassword;
	private String secretQuestion;
	private String transactionPassword;
	private String lockStatus;
	private String accountNumber;
	private String newPassword;

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public String getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

}
