/**
 * 
 */
package com.capGbank.beans;

import java.util.Date;

/**
 * @author ypambi
 * 
 * 
 * create table service_tracker(serviceId number,
serviceDescription varchar(50),accountNumber number,serviceRaisedDate DATE,
serviceStatus varchar(30),
primary key(serviceId),foreign key(accountNumber)
 references Account_master(accountNumber));
 *
 */
public class ServiceTracker {
	
	private int serviceId;
	private String serviceDescription;
	private String accountNumber;
	private Date serviceRaisedDate;
	private String serviceStatus;
	public int getserviceId() {
		return serviceId;
	}
	public void setserviceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getserviceDescription() {
		return serviceDescription;
	}
	public void setserviceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	public String getaccountNumber() {
		return accountNumber;
	}
	public void setaccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Date getserviceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setserviceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getserviceStatus() {
		return serviceStatus;
	}
	public void setserviceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	

}
