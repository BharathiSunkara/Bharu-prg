/**
 * 
 */
package com.capGbank.service;

import java.util.List;
import java.util.regex.Pattern;

import com.capGbank.beans.AccountMaster;
import com.capGbank.beans.AdminTable;
import com.capGbank.beans.ServiceTracker;
import com.capGbank.beans.Transactions;
import com.capGbank.beans.UserTable;
import com.capGbank.dao.CapGbankDaoImpl;
import com.capGbank.dao.ICapGbankDao;
import com.capGbank.exception.CapgbankException;

/**
 * @author ypambi
 *
 */
public class CapGbankServiceImpl implements ICapGbankService{
	
	ICapGbankDao icapd;

	@Override
	public boolean authenticateUser(String username, String password) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		boolean autUsr = icapd.authenticateUser(username,password);
		return autUsr;
	}

	@Override
	public boolean authenticateAdmin(String username, String password) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		boolean autAdm = icapd.authenticateAdmin(username,password);
		return autAdm;
	}

	@Override
	public AccountMaster createNewAccount(AccountMaster am)
			throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		AccountMaster cna = icapd.createNewAccount(am);
		return cna;
	}

	@Override
	public List<Transactions> retriveTransactionDetails() throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		List<Transactions> rtd = icapd.retriveTransactionDetails();
		return rtd;
	}

	@Override
	public List<Transactions> getMiniStatement(String accountNo) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		List<Transactions> transactions = null;
		transactions = icapd.getMiniStatement(accountNo);
		return transactions;
	}

	@Override
	public void updateCustomerDetails(AccountMaster am)
			throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		icapd.updateCustomerDetails(am);
		
	}

	@Override
	public int requestChequeBook(ServiceTracker st)
			throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		int rcst = icapd.requestChequeBook(st);
		return rcst;
	}

	@Override
	public void fundTransfer(Transactions trans) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		icapd.fundTransfer(trans);
		
	}

	@Override
	public void changePassword(UserTable ut) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		icapd.changePassword(ut);
		
	}

	@Override
	public List<ServiceTracker> trackService(ServiceTracker stq) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		List<ServiceTracker> st = icapd.trackService(stq);
		return st;
	}

	@Override
	public String getAccountNumber(String userid) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		String acno = icapd.getAccountNumber(userid);
		return acno;
	}

	@Override
	public List<String> getAccountNumbers() throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		List<String> acnos = icapd.getAccountNumbers();
		return acnos;
	}

	@Override
	public UserTable createIbankingUsers(UserTable am) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		UserTable ut = icapd.createIbankingUsers(am);
		return ut;
	}

	@Override
	public boolean authFundTranfer(String userId, String transPassword)
			throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		boolean authTrans = icapd.authFundTranfer(userId, transPassword);
		return authTrans;
	}

	@Override
	public double getAccBalance(String acno) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		double balance = icapd.getAccBalance(acno);
		return balance;
	}

	@Override
	public double totalTransAmount(String username) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		double totalTransAmt = icapd.totalTransAmount(username);
		return totalTransAmt;
	}

	@Override
	public boolean validateServiceId(String servId) {
		String patterns1 = "\\d{1,8}";
		if (Pattern.matches(patterns1, servId)) {
			return true;
		} else {

			return false;
		}
	}

	@Override
	public boolean isDigit(String value) {
		String patterns1 = "\\d{1,}";
		if (Pattern.matches(patterns1, value)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean validateMailId(String MailId) {
		String patterns = "[A-Za-z0-9]{1,}[@][A-Za-z0-9.]{1,}";
		if (Pattern.matches(patterns, MailId)) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public String getTransPass(String username, String scQs) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		String rePass = icapd.getTransPass(username,scQs);
		return rePass;
	}

	@Override
	public List<ServiceTracker> showAllServReqs() throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		
		List<ServiceTracker> st = icapd.showAllServReqs();
		return st;
		
	}

	@Override
	public void updateServiceReq(ServiceTracker st) throws CapgbankException {
		icapd = new CapGbankDaoImpl();
		icapd.updateServiceReq(st);
		
	}

	@Override
	public boolean validatePassword(String loginPass) {
		String patterns = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$";
		if (Pattern.matches(patterns, loginPass)) {
			return true;
		} else {
			return false;
		}
	}

}
