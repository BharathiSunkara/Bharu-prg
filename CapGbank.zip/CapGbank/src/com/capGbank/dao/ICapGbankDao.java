/**
 * 
 */
package com.capGbank.dao;

import java.util.List;

import com.capGbank.beans.AccountMaster;
import com.capGbank.beans.AdminTable;
import com.capGbank.beans.ServiceTracker;
import com.capGbank.beans.Transactions;
import com.capGbank.beans.UserTable;
import com.capGbank.exception.CapgbankException;




/**
 * @author ypambi
 *
 */
public interface ICapGbankDao {
	
	public boolean authenticateUser(String username, String password) throws CapgbankException;
	public boolean authenticateAdmin(String username, String password) throws CapgbankException;
	public boolean authFundTranfer(String userId, String transPassword) throws CapgbankException;
	public AccountMaster createNewAccount(AccountMaster am) throws CapgbankException;
	public List<Transactions> retriveTransactionDetails() throws CapgbankException;
	public List<Transactions> getMiniStatement(String accountNo) throws CapgbankException;
	public void updateCustomerDetails(AccountMaster am ) throws CapgbankException;
	public int requestChequeBook(ServiceTracker st) throws CapgbankException;
	public void fundTransfer(Transactions trans) throws CapgbankException;
	public void changePassword(UserTable ut) throws CapgbankException;
	public List<ServiceTracker> trackService(ServiceTracker stq) throws CapgbankException;
	public String getAccountNumber(String userid) throws CapgbankException;
	public List<String> getAccountNumbers() throws CapgbankException;
	public UserTable createIbankingUsers(UserTable am) throws CapgbankException; 
	public double getAccBalance(String acno) throws CapgbankException;
	public double totalTransAmount(String username) throws CapgbankException;
	public String getTransPass(String username, String scQs) throws CapgbankException;
	public List<ServiceTracker> showAllServReqs() throws CapgbankException;
	public void updateServiceReq(ServiceTracker st) throws CapgbankException;
	
}
