/**
 * 
 */
package com.capGbank.dao;

/**
 * @author ypambi
 *
 */
public interface IQueryMapper {

	static String AUTH_ADMIN_USER = "select * from admintable";
	static String AUTH_USER = "SELECT user_id,login_password FROM user_table";
	static String NEW_ACCOUNT = "INSERT INTO Account_Master VALUES(Account_Number_seq.nextval,?,?,sysdate,5,?,?,?,?)";
	static String INSERT_TRANS_DETAILS = "insert into transactions values(transaction_id_seq.nextval,?,sysdate,?,?,?,?,?)";
	static String RETRIVE_MINISTATEMENT_QUERY = "SELECT * FROM transactions where account_number = ?";
	static String UPDATE_PAYER_BALANCE = "update account_master set Account_balance = (Account_balance-?) where Account_number = ?";
	static String UPDATE_PAYEE_BALANCE = "update account_master set Account_balance = (Account_balance+?) where Account_number = ?";
	static String RETRIVE_ALL_TRANSACTIONS_QUERY = "SELECT * FROM transactions";
	static String UPDATE_ADDRESS = "update account_master set Address = ? where Account_number = ?";
	static String GET_SERVICE_ID = "SELECT service_req_seq.CURRVAL FROM DUAL";
	static String GET_ACCOUNT_NO_SEQ = "SELECT Account_Number_seq.CURRVAL FROM DUAL";
	static String INSERT_SERVICE_TRACKER = "INSERT INTO service_tracker VALUES(service_req_seq.nextval,?,?,sysdate,'InProgress')";
	static String GET_SERVICE_DETAILS = "select * from service_tracker where (account_number = ? or service_id =?)";
	static String CHANGE_PASSWORD = "update user_table set LOGIN_PASSWORD = ? where (USER_ID = ? and LOGIN_PASSWORD = ?)";
	static String GET_ACCOUNT_NOS = "select  ACCOUNT_NUMBER from account_master";
	static String GET_ACCOUNT_NO = "select  ACCOUNT_NUMBER from user_table where user_id = ?";
	static String NEW_IUSER = "INSERT INTO USER_TABLE VALUES(?,?,?,?,'disabled',?)";
	static String AUTH_FUND_TRANSFER = "SELECT TRANSACTION_PASSWORD FROM user_table WHERE USER_ID = ?";
	static String GET_ACCOUNT_BAL = "select ACCOUNT_BALANCE from Account_Master where ACCOUNT_NUMBER =?";
	static String GET_TOTAL_LIMIT ="select sum(TRANSACTION_AMOUNT) from transactions LD WHERE (TRANSACTION_STATUS = 'Success' and (account_number = ?) and (to_date(SYSDATE, 'dd/mm/rr') = to_date( LD.DATE_OF_TRANSACTION, 'dd/mm/rr' )))";
	static String GET_PASS_RECOVR = "select TRANSACTION_PASSWORD from user_table where (user_id = ? and SECRET_QUESTION =?)";
	static String GET_ALL_SERVICE_DETAILS = "select * from service_tracker";
	static String UPDATE_SERVICE_REQUEST = "UPDATE service_tracker SET SERVICE_STATUS = ? where (account_number = ? or service_id =?)";
	

}
