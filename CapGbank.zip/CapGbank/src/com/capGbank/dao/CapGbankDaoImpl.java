/**
 * 
 */
package com.capGbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capGbank.beans.AccountMaster;
import com.capGbank.beans.AdminTable;
import com.capGbank.beans.ServiceTracker;
import com.capGbank.beans.Transactions;
import com.capGbank.beans.UserTable;
import com.capGbank.exception.CapgbankException;
import com.capGbank.util.DBConnecton;








/**
 * @author ypambi
 * 
 * 
 * Account_Number NUMBER,Account_Type VARCHAR(25), Account_balance
 *         NUMBER,Open_Date DATE,Interest_rate NUMBER, Account_Holder_Name
 *         VARCHAR(30), Email VARCHAR(30) UNIQUE,Address VARCHAR(30),pan_number
 *         varchar(30) UNIQUE,PRIMARY KEY(Account_number)
 *
 */
public class CapGbankDaoImpl implements ICapGbankDao {

	@Override
	public boolean authenticateUser(String username, String password) throws CapgbankException {
		Connection conn;
		conn = DBConnecton.getConnection();
		int usersCount = 0;
		PreparedStatement authUserStmt = null;
		List<UserTable> usersList = new ArrayList<UserTable>();
		try {
			authUserStmt = conn.prepareStatement(IQueryMapper.AUTH_USER);
			ResultSet userResultSet = authUserStmt.executeQuery();
			while (userResultSet.next()) {
				UserTable ut = new UserTable();
				ut.setUserId(userResultSet.getString(1));
				ut.setLoginPassword(userResultSet.getString(2));
				
				usersList.add(ut);

				usersCount++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new CapgbankException("auth cannot perform");
		}
		if (usersList != null) {
			Iterator<UserTable> i = usersList.iterator();
			while (i.hasNext()) {
				UserTable obj = i.next();
				if(obj.getUserId().equals(username)&&obj.getLoginPassword().equals(password)) {
					return true;
				}
			}
			return false;
		}
		return false; 
	}

	@Override
	public boolean authenticateAdmin(String username, String password) throws CapgbankException {
		Connection conn;
		conn = DBConnecton.getConnection();
		int adminCount = 0;
		PreparedStatement authUserStmt = null;
		List<AdminTable> adminsList = new ArrayList<AdminTable>();
		try {
			authUserStmt = conn.prepareStatement(IQueryMapper.AUTH_ADMIN_USER);
			ResultSet userResultSet = authUserStmt.executeQuery();
			while (userResultSet.next()) {
				AdminTable at = new AdminTable();
				at.setAdminUserName(userResultSet.getString(1));
				at.setAdminPassword(userResultSet.getString(2));
				
				adminsList.add(at);

				adminCount++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new CapgbankException("auth cannot perform");
		}
		
		if (adminsList != null) {
			Iterator<AdminTable> i = adminsList.iterator();
			while (i.hasNext()) {
				AdminTable obj = i.next();
				if((obj.getAdminUserName().equals(username))&&obj.getAdminPassword().equals(password)) {
					return true;
				}
			}
			return false;
		}
		return false; 
		
	}
	
	
	
	
	
	
	
	public List<String> getAccountNumbers() throws CapgbankException {

		Connection con = DBConnecton.getConnection();
		int mobileIDsCount = 0;

		PreparedStatement psMobIDStmt = null;
		ResultSet resultsetMobId = null;

		List<String> mobileIDsList = new ArrayList<String>();
		try {
			psMobIDStmt = con.prepareStatement(IQueryMapper.GET_ACCOUNT_NOS);
			resultsetMobId = psMobIDStmt.executeQuery();

			while (resultsetMobId.next()) {
				mobileIDsList.add(resultsetMobId.getString(1));

				mobileIDsCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new CapgbankException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultsetMobId.close();
				psMobIDStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new CapgbankException("Error in closing db connection");

			}
		}

		if (mobileIDsCount == 0)
			return null;
		else
			return mobileIDsList;

	}
	
	
	
	
	
	
	
	
	
	public String getAccountNumber(String userid) throws CapgbankException {

		Connection con = DBConnecton.getConnection();
		int mobileIDsCount = 0;

		PreparedStatement psMobIDStmt = null;
		ResultSet resultsetMobId = null;

		String mobileIDsList="";
		try {
			psMobIDStmt = con.prepareStatement(IQueryMapper.GET_ACCOUNT_NO);
			psMobIDStmt.setString(1, userid);
			resultsetMobId = psMobIDStmt.executeQuery();

			while (resultsetMobId.next()) {
				mobileIDsList=resultsetMobId.getString(1);

				mobileIDsCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new CapgbankException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultsetMobId.close();
				psMobIDStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new CapgbankException("Error in closing db connection");

			}
		}

		if (mobileIDsCount == 0)
			return null;
		else
			return mobileIDsList;

	}
	
	
	
	
	
	
	
	
	

	@Override
	public AccountMaster createNewAccount(AccountMaster am)
			throws CapgbankException {
		Connection conn;

		PreparedStatement psUpdateAmTab = null;

		try {

			conn = DBConnecton.getConnection();

			psUpdateAmTab = conn.prepareStatement(IQueryMapper.NEW_ACCOUNT);
			psUpdateAmTab.setString(1, am.getAccountType());
			psUpdateAmTab.setDouble(2, am.getAccountBalance());
			psUpdateAmTab.setString(3, am.getAccountHolderName());
			psUpdateAmTab.setString(4, am.getEmail());
			psUpdateAmTab.setString(5, am.getAddress());
			psUpdateAmTab.setString(6, am.getPanNumber());
			

			int result = psUpdateAmTab.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new CapgbankException("Sorry! new Account cannot be created");
			} else {
				conn.commit();
				System.out.println("\nNew Account Created Successfully with Account Number: "+getAccountNo()+"\n");
			}

		} catch (SQLException | NullPointerException e) {

			throw new CapgbankException(e.getMessage());
		}

		return am;
	}

	
	
	@Override
	public UserTable createIbankingUsers(UserTable am)
			throws CapgbankException {
		Connection conn;

		PreparedStatement psUpdateAmTab = null;

		try {

			conn = DBConnecton.getConnection();

			psUpdateAmTab = conn.prepareStatement(IQueryMapper.NEW_IUSER);
			psUpdateAmTab.setString(1, am.getUserId());
			psUpdateAmTab.setString(2, am.getLoginPassword());
			psUpdateAmTab.setString(3, am.getSecretQuestion());
			psUpdateAmTab.setString(4, am.getTransactionPassword());
			psUpdateAmTab.setString(5, am.getAccountNumber());
			

			int result = psUpdateAmTab.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new CapgbankException("Sorry! new Account cannot be created");
			} else {
				conn.commit();
				System.out.println("\nNew Internet Banking User Created Successfully\n");
			}

		} catch (SQLException | NullPointerException e) {

			throw new CapgbankException(e.getMessage());
		}

		return am;
	}

	
	
	
	
	
	
	
	
	@Override
	public List<Transactions> retriveTransactionDetails() throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		int transacCount = 0;

		PreparedStatement psTransStmt = null;
		ResultSet resultset = null;

		List<Transactions> ministatementList = new ArrayList<Transactions>();
		try {
			psTransStmt = con.prepareStatement(IQueryMapper.RETRIVE_ALL_TRANSACTIONS_QUERY);
			resultset = psTransStmt.executeQuery();

			while (resultset.next()) {
				Transactions trans = new Transactions();
				trans.setTransactionId(resultset.getLong(1));
				trans.setTransactionDescription(resultset.getString(2));
				trans.setDateOfTransaction(resultset.getDate(3));
				trans.setTransactionType(resultset.getString(4));
				trans.setTransactionAmount(resultset.getDouble(5));
				trans.setAccountNumber(resultset.getString(6));
				trans.setTransactionStatus(resultset.getString(7));
				trans.setPayeeAccountId(resultset.getString(8));
				ministatementList.add(trans);

				transacCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new CapgbankException("Tehnical problem occured. Refer log");
		}

		/*
		 * finally { try { resultset.close(); psTransStmt.close(); // con.close(); }
		 * catch (SQLException e) { //logger.error(e.getMessage()); throw new
		 * CapgbankException("Error in closing db connection");
		 * 
		 * } }
		 */

		if (transacCount == 0)
			return null;
		else
			return ministatementList;	
		
	}

	@Override
	public List<Transactions> getMiniStatement(String accountNo) throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		int mobilesCount = 0;

		PreparedStatement psMobStmt = null;
		ResultSet resultset = null;

		List<Transactions> ministatementList = new ArrayList<Transactions>();
		try {
			psMobStmt = con.prepareStatement(IQueryMapper.RETRIVE_MINISTATEMENT_QUERY);
			psMobStmt.setString(1, accountNo);
			resultset = psMobStmt.executeQuery();

			while (resultset.next()) {
				Transactions miniTrans = new Transactions();
				miniTrans.setTransactionId(resultset.getLong(1));
				miniTrans.setTransactionDescription(resultset.getString(2));
				miniTrans.setDateOfTransaction(resultset.getDate(3));
				miniTrans.setTransactionType(resultset.getString(4));
				miniTrans.setTransactionAmount(resultset.getDouble(5));
				miniTrans.setAccountNumber(resultset.getString(6));
				miniTrans.setTransactionStatus(resultset.getString(7));
				miniTrans.setPayeeAccountId(resultset.getString(8));
				ministatementList.add(miniTrans);

				mobilesCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new CapgbankException("Tehnical problem occured. Refer log");
		}

		/*
		 * finally { try { resultset.close(); psMobStmt.close(); // con.close(); } catch
		 * (SQLException e) { //logger.error(e.getMessage()); throw new
		 * CapgbankException("Error in closing db connection");
		 * 
		 * } }
		 */

		if (mobilesCount == 0)
			return null;
		else
			return ministatementList;
	}

	@Override
	public void updateCustomerDetails(AccountMaster am)
			throws CapgbankException {
		
		Connection con = DBConnecton.getConnection();
		PreparedStatement psUpdateCustDetails = null;
		try {
			psUpdateCustDetails = con.prepareStatement(IQueryMapper.UPDATE_ADDRESS);
			psUpdateCustDetails.setString(1, am.getAddress());
			psUpdateCustDetails.setString(2, am.getAccountNumber());
			int result = psUpdateCustDetails.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				System.out.println("No Details Found With This Account Number");
			} else {
				con.commit();
				System.out.println("\nAdddress Updated Successfully\n");
			}
		}catch (SQLException e) {
				throw new CapgbankException("\nexception raised at address update\n");
			}
		
		
	}

	@Override
	public int requestChequeBook(ServiceTracker st)
			throws CapgbankException {
		Connection conn;
		PreparedStatement psUpdateServiceTab = null;

		try {

			conn = DBConnecton.getConnection();

			psUpdateServiceTab = conn.prepareStatement(IQueryMapper.INSERT_SERVICE_TRACKER);
			psUpdateServiceTab.setString(1, st.getserviceDescription());
			psUpdateServiceTab.setString(2, st.getaccountNumber());

			int result = psUpdateServiceTab.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new CapgbankException("Sorry! new Account cannot be created");
			} else {
				conn.commit();
				System.out.println("\nYour request was recorded Successfully\n");
			}

		} catch (SQLException | NullPointerException e) {

			throw new CapgbankException(e.getMessage());
		}

		return getServiceId();
	}
	
	
	public int getServiceId() throws CapgbankException {

		Connection conn;
		PreparedStatement getServiceStmt = null;
		ResultSet serviceIdResult = null;
		int purchaseid = 0;
		try {
			conn = DBConnecton.getConnection();
			getServiceStmt = conn.prepareStatement(IQueryMapper.GET_SERVICE_ID);
			serviceIdResult = getServiceStmt.executeQuery();
			if (serviceIdResult.next()) {
				purchaseid = serviceIdResult.getInt(1);
				//logger.info("Registation done: " + purchaseid);
			}
		} catch (CapgbankException e) {
			throw new CapgbankException("Sorry serviceId not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new CapgbankException("Sorry serviceId sql exception genrated");

		}

		return purchaseid;

	}
	
	
	
	
	public String getAccountNo() throws CapgbankException {

		Connection conn;
		PreparedStatement getAccountStmt = null;
		ResultSet serviceIdResult = null;
		String accountSeq  = null;
		try {
			conn = DBConnecton.getConnection();
			getAccountStmt = conn.prepareStatement(IQueryMapper.GET_ACCOUNT_NO_SEQ);
			serviceIdResult = getAccountStmt.executeQuery();
			if (serviceIdResult.next()) {
				accountSeq = serviceIdResult.getString(1);
				//logger.info("Registation done: " + purchaseid);
			}
		} catch (CapgbankException e) {
			throw new CapgbankException("Sorry serviceId not genrated");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new CapgbankException("Sorry serviceId sql exception genrated");

		}

		return accountSeq;

	}
	
	
	
	
	
	
	
	

	@Override
	public void fundTransfer(Transactions trans) throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		PreparedStatement psUpdatePayer = null;
		PreparedStatement psUpdatePayee = null;
		PreparedStatement psUpdateTransTab = null;
		try {
			psUpdatePayer = con.prepareStatement(IQueryMapper.UPDATE_PAYER_BALANCE);
			if(getAccBalance(trans.getAccountNumber())>=trans.getTransactionAmount()) {
			psUpdatePayer.setDouble(1, trans.getTransactionAmount());
			psUpdatePayer.setString(2, trans.getAccountNumber());
			int result = psUpdatePayer.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new CapgbankException("transaction update at payer failed");
			} else {
				con.commit();
			}
			
			psUpdatePayee = con.prepareStatement(IQueryMapper.UPDATE_PAYEE_BALANCE);
			psUpdatePayee.setDouble(1, trans.getTransactionAmount());
			psUpdatePayee.setString(2, trans.getPayeeAccountId());
			int result2 = psUpdatePayee.executeUpdate();
			
			if (result2 != 1) {
				//logger.debug("values not inserted");
				throw new CapgbankException("transaction update at payee failed");
			} else {
				con.commit();
				System.out.println("\nTransaction Successful\n");
			}
			
			psUpdateTransTab = con.prepareStatement(IQueryMapper.INSERT_TRANS_DETAILS);
			psUpdateTransTab.setString(1, trans.getTransactionDescription());
			psUpdateTransTab.setString(2, trans.getTransactionType());
			psUpdateTransTab.setDouble(3, trans.getTransactionAmount());
			psUpdateTransTab.setString(4, trans.getAccountNumber());
			psUpdateTransTab.setString(5, "Success");
			psUpdateTransTab.setString(6, trans.getPayeeAccountId());
			

			int result3 = psUpdateTransTab.executeUpdate();

			if (result != 1) {
				//logger.debug("values not inserted");
				throw new CapgbankException("\nTransaction details update failed");
			} else {
				con.commit();
				//System.out.println("\nNew Transaction  Successfully\n");
			}
			
			}
			
			else {
				
				
				
				
				psUpdateTransTab = con.prepareStatement(IQueryMapper.INSERT_TRANS_DETAILS);
				psUpdateTransTab.setString(1, trans.getTransactionDescription());
				psUpdateTransTab.setString(2, trans.getTransactionType());
				psUpdateTransTab.setDouble(3, trans.getTransactionAmount());
				psUpdateTransTab.setString(4, trans.getAccountNumber());
				psUpdateTransTab.setString(5, "Failed");
				psUpdateTransTab.setString(6, trans.getPayeeAccountId());
				

				int result3 = psUpdateTransTab.executeUpdate();
				con.commit();
				System.out.println("\nTransaction Failed Due to Insufficient Funds..!! ");
			}

		} catch (SQLException | CapgbankException e) {
			throw new CapgbankException("\nTransaction failed\n");
		}
		
	}

	@Override
	public void changePassword(UserTable ut) throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		PreparedStatement psUpdatePass = null;
		try {
			psUpdatePass  = con.prepareStatement(IQueryMapper.CHANGE_PASSWORD);
			psUpdatePass.setString(1, ut.getNewPassword());
			psUpdatePass.setString(2, ut.getUserId());
			psUpdatePass.setString(3, ut.getLoginPassword());
			
			int result = psUpdatePass.executeUpdate();
			
			if (result != 1) {
				//logger.debug("values not inserted");
				System.out.println("Wrong Username or Password ");
			} 
			else {
				con.commit();
				System.out.println("\nPassword Updated Successfully\n");
			}
			} catch (SQLException e) {
				throw new CapgbankException("\nTPassword update failed\n");
			}
			
		
	}

	@Override
	public List<ServiceTracker> trackService(ServiceTracker stq) throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		int servicesCount = 0;

		PreparedStatement psServStmt = null;
		ResultSet resultset = null;

		List<ServiceTracker> servicestList = new ArrayList<ServiceTracker>();
		try {
			psServStmt = con.prepareStatement(IQueryMapper.GET_SERVICE_DETAILS);
			psServStmt.setString(1, stq.getaccountNumber());
			psServStmt.setInt(2, stq.getserviceId());
			resultset = psServStmt.executeQuery();

			while (resultset.next()) {
				ServiceTracker servtrck = new ServiceTracker();
				servtrck.setserviceId(resultset.getInt(1));
				servtrck.setserviceDescription(resultset.getString(2));
				servtrck.setaccountNumber(resultset.getString(3));
				servtrck.setserviceRaisedDate(resultset.getDate(4));
				servtrck.setserviceStatus(resultset.getString(5));
				servicestList.add(servtrck);

				servicesCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new CapgbankException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultset.close();
				psServStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new CapgbankException("Error in closing db connection");

			}
		}

		if (servicesCount == 0)
			return null;
		else
			return servicestList;
	}

	@Override
	public boolean authFundTranfer(String userId, String transPassword)
			throws CapgbankException {
		Connection conn;
		conn = DBConnecton.getConnection();
		int usersCount = 0;
		PreparedStatement authUserStmt = null;
		List<UserTable> usersList = new ArrayList<UserTable>();
		try {
			authUserStmt = conn.prepareStatement(IQueryMapper.AUTH_FUND_TRANSFER);
			authUserStmt.setString(1, userId);
			ResultSet userResultSet = authUserStmt.executeQuery();
			while (userResultSet.next()) {
				UserTable ut = new UserTable();
				ut.setTransactionPassword(userResultSet.getString(1));
				
				usersList.add(ut);

				usersCount++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new CapgbankException("auth cannot perform");
		}
		if (usersList != null) {
			Iterator<UserTable> i = usersList.iterator();
			while (i.hasNext()) {
				UserTable obj = i.next();
				if(obj.getTransactionPassword().equals(transPassword)) {
					return true;
				}
			}
			return false;
		}
		return false; 
	}

	@Override
	public double getAccBalance(String acno) throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		int mobileIDsCount = 0;

		PreparedStatement psMobIDStmt = null;
		ResultSet resultsetMobId = null;

		double mobileIDsList=0;
		try {
			psMobIDStmt = con.prepareStatement(IQueryMapper.GET_ACCOUNT_BAL);
			psMobIDStmt.setString(1, acno);
			resultsetMobId = psMobIDStmt.executeQuery();

			while (resultsetMobId.next()) {
				mobileIDsList=resultsetMobId.getDouble(1);

				mobileIDsCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new CapgbankException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultsetMobId.close();
				psMobIDStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new CapgbankException("Error in closing db connection");

			}
		}

		if (mobileIDsCount == 0)
			return 0;
		else
			return mobileIDsList;

	}

	@Override
	public double totalTransAmount(String username) throws CapgbankException {
		Connection conn =DBConnecton.getConnection();
		PreparedStatement psLimit = null;
		double totalTrans = 0;
		try {
			psLimit = conn.prepareStatement(IQueryMapper.GET_TOTAL_LIMIT);
			psLimit.setString(1, getAccountNumber(username));
			ResultSet tot = psLimit.executeQuery();
			while(tot.next()) {
				totalTrans = tot.getDouble(1);
				return totalTrans;
			}
			
			
		} catch (SQLException e) {
			throw new CapgbankException(e.getMessage());
		}
		return 0;
	}

	@Override
	public String getTransPass(String username, String scQs) throws CapgbankException {
		Connection conn =DBConnecton.getConnection();
		PreparedStatement psLimit = null;
		String totalTrans = "";
		try {
			psLimit = conn.prepareStatement(IQueryMapper.GET_PASS_RECOVR);
			psLimit.setString(1, username);
			psLimit.setString(2, scQs);
			ResultSet tot = psLimit.executeQuery();
			while(tot.next()) {
				totalTrans = tot.getString(1);
				return "Your Transaction Password is: "+totalTrans+".\nPlease Enter this password, To complete Transaction";
			}
			
			
		} catch (SQLException e) {
			throw new CapgbankException(e.getMessage());
		}
		return null;
	}

	@Override
	public List<ServiceTracker> showAllServReqs() throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		int servicesCount = 0;

		PreparedStatement psServStmt = null;
		ResultSet resultset = null;

		List<ServiceTracker> servicestList = new ArrayList<ServiceTracker>();
		try {
			psServStmt = con.prepareStatement(IQueryMapper.GET_ALL_SERVICE_DETAILS);
			resultset = psServStmt.executeQuery();

			while (resultset.next()) {
				ServiceTracker servtrck = new ServiceTracker();
				servtrck.setserviceId(resultset.getInt(1));
				servtrck.setserviceDescription(resultset.getString(2));
				servtrck.setaccountNumber(resultset.getString(3));
				servtrck.setserviceRaisedDate(resultset.getDate(4));
				servtrck.setserviceStatus(resultset.getString(5));
				servicestList.add(servtrck);

				servicesCount++;
			}

		} catch (SQLException sqlException) {
			//logger.error(sqlException.getMessage());
			throw new CapgbankException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultset.close();
				psServStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new CapgbankException("Error in closing db connection");

			}
		}

		if (servicesCount == 0)
			return null;
		else
			return servicestList;
		
	}

	@Override
	public void updateServiceReq(ServiceTracker st) throws CapgbankException {
		Connection con = DBConnecton.getConnection();
		PreparedStatement psUpdatePass = null;
		try {
			psUpdatePass  = con.prepareStatement(IQueryMapper.UPDATE_SERVICE_REQUEST);
			psUpdatePass.setString(1, "Dispatched");
			psUpdatePass.setString(2, st.getaccountNumber());
			psUpdatePass.setInt(3, st.getserviceId());
			
			
			int result = psUpdatePass.executeUpdate();
			
			if (result != 1) {
				//logger.debug("values not inserted");
				System.out.println("No Service Requests Found With the given details!! ");
			} 
			else {
				con.commit();
				System.out.println("\nService Processed Successfully \n");
			}
			} catch (SQLException e) {
				throw new CapgbankException("\nService Request update failed\n");
			}
	}

}
