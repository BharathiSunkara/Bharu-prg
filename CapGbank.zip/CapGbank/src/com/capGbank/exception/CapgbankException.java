package com.capGbank.exception;

public class CapgbankException extends Exception{
	public CapgbankException(String msg) {
		super(msg);
	}

}
