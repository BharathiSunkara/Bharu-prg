/**
 * 
 */
package com.capGbank.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capGbank.beans.AccountMaster;
import com.capGbank.beans.ServiceTracker;
import com.capGbank.beans.Transactions;
import com.capGbank.beans.UserTable;
import com.capGbank.exception.CapgbankException;
import com.capGbank.service.CapGbankServiceImpl;
import com.capGbank.service.ICapGbankService;

/**
 * @author ypambi
 *
 */
public class Client {

	static Scanner in;
	static ICapGbankService icaps = new CapGbankServiceImpl();

	public static void main(String[] args) throws CapgbankException {
		in = new Scanner(System.in);

		System.out.println(" \nWelcome to CapGbank Portal\n");
		while (true) {
			System.out.println(" \nEnter your choice:");
			System.out.println("\n 1.Customer Login\n\n 2.Admin Login\n\n 3.Exit Application\n");
			String option1 = in.next();
			switch (option1) {
			case "1":
				System.out.println("Authentication Required, Please provide your Login credentials\n");
				System.out.println("Enter your username");
				String username = in.next();
				System.out.println("Enter your password");
				String password = in.next();
				if (icaps.authenticateUser(username, password)) {
					System.out.println("\nWelcome to CapGbank Customer Portal  ");
					
					String choice = "0";
					while (!choice.equals("7")) {
						System.out.println("\nYour Account Balance is: "+icaps.getAccBalance(icaps.getAccountNumber(username)));
						System.out.println(" \nEnter your choice:\n");
						System.out.println(" 1.View Mini-Statement\n");
						System.out.println(" 2.Update Details\n");
						System.out.println(" 3.Request Cheque Book\n");
						System.out.println(" 4.Fund Transfer\n");
						System.out.println(" 5.Change Password\n");
						System.out.println(" 6.Track Service\n");
						System.out.println(" 7.Logout\n");
						choice = in.next();
						switch (choice) {

						case "1":
							getMiniStatement(username);
							break;

						case "2":
							updateDetails(username);
							break;

						case "3":
							requestChequeBook(username);
							break;

						case "4":
							fundTransfer(username);
							break;

						case "5":
							changePassword(username);
							break;

						case "6":
							trackService();
							break;

						case "7":
							System.out.println("\n\nThank you");
							break;

						}

					}
				} else {
					System.out.println("Invalid Credentials");
				}
				break;

			case "2":
				System.out.println("Authentication Required, Please provide your Login credentials\n");
				System.out.println("Enter your username");
				String username1 = in.next();
				System.out.println("Enter your password");
				String password1 = in.next();
				if (icaps.authenticateAdmin(username1, password1)) {
					System.out.println("\nWelcome to CapGbank Admin Portal  ");
					String choice2 = "0";
					while (!choice2.equals("5")) {
						System.out.println(" \nEnter your choice:\n");
						System.out.println(" 1.Create New Account\n");
						System.out.println(" 2.Create New Internet Banking User\n");
						System.out.println(" 3.View Transaction Reports\n");
						System.out.println(" 4.Process Service Request\n");
						System.out.println(" 5.Logout\n");
						choice2 = in.next();

						switch (choice2) {

						case "1":
							String option = "0";
							do {
								createNewAccount();
								System.out.println("To Create Another Account Press 1, Else Press any other DIGIT");
								option = in.next();
							} while (option.equals("1"));
							break;

						case "2":
							createIusers();
							break;
							
						case "3":
							viewAllTransactions();
							break;
							
						case "4":
							ProcessRequest();
							break;

						case "5":
							System.out.println("\n\nThank you");
							break;

						}

					}
				} else {
					System.out.println("Invalid Login Credentials");
				}
				break;
			case "3":
				System.out.println("Have a nice day!!. Goodbye!!. ");
				System.exit(0);
			}
		}
	}

	private static void ProcessRequest() throws CapgbankException {
		
			try {
				List<ServiceTracker> mobilesList = new ArrayList<ServiceTracker>();
				mobilesList = icaps.showAllServReqs();

				if (mobilesList != null) {
					Iterator<ServiceTracker> i = mobilesList.iterator();
					System.out.println("Id    " + "Description  " + "A/c_no   "+ "Date     "+ " Status \n");
					while (i.hasNext()) {
						ServiceTracker obj = i.next();
						System.out.println(
								obj.getserviceId() + " " + obj.getserviceDescription() + " " + obj.getaccountNumber() + " "
										+ obj.getserviceRaisedDate() + " " + obj.getserviceStatus() + "\n");

					}
				} else {
					System.out.println("\nNo Service Requsets Found for the Given Details!!\n");
				}

			} catch (CapgbankException e) {

				System.out.println("Error  :" + e.getMessage());
			}
			
			System.out.println("\nEnter Service Id or Account number From the Table To Update Status");
			ServiceTracker st = new ServiceTracker();
			String serviceId ="";
			while(true) {
				serviceId = in.next();
				if(icaps.validateServiceId(serviceId)) {
					break;
				}
				else{
					System.out.println("Enter valid digits");
				}
			}
			int servId = Integer.parseInt(serviceId);
			st.setserviceId(servId);
			String acno = serviceId;
			st.setaccountNumber(acno);
			
			icaps.updateServiceReq(st);
			
			
			
			
		
	}


	private static void createIusers() throws CapgbankException {
		UserTable ut = new UserTable();
		String userid;
		String loginPass;
		String secretQs;
		String transPass;
		String lockSta;
		String accountNumber;
		System.out.println("Enter User Id");
		userid = in.next();
		System.out.println("Enter login password");
		while(true) {
			loginPass =in.next();
			if(icaps.isDigit(loginPass)) {
				break;
			}
			else{
				System.out.println("Enter only digits");
			}
		}
		
		System.out.println("Enter  Your Secret Q's:\n1.What Is Your Birth City ?"
				+ "\n2.Who Is Your Favorite Actor ?"
				+ "\n3.What Is Your Pet Name ?");
		String Qsoption = in.next();
		secretQs = "";
		switch(Qsoption) {
		case "1":
			secretQs ="What Is Your Birth City ?";
			break;
		case "2":
			secretQs ="Who Is Your Favorite Actor ?";
			break;
		case "3":
			secretQs ="What Is Your Pet Name ?";
			break;
		
		}
		System.out.println("Enter Your Ans:");
		secretQs += in.next().toLowerCase();
		System.out.println("Enter Transaction Password");
		transPass = in.next();
		System.out.println("Enter Account Number");
		accountNumber=in.next();
		ut.setUserId(userid);
		ut.setLoginPassword(loginPass);
		ut.setSecretQuestion(secretQs);
		ut.setTransactionPassword(transPass);
		ut.setAccountNumber(accountNumber);
		icaps.createIbankingUsers(ut);
		
		
	}

	private static void getMiniStatement(String username) throws CapgbankException {
		String accountNumber = icaps.getAccountNumber(username);
		miniStatement(accountNumber);
		
	}

	private static void changePassword(String user) throws CapgbankException {
		UserTable ut = new UserTable();
		String newPass;
		System.out.println("Enter your Old Password");
		String oldPass = in.next();
		
		
		System.out.println("Enter Your New Password");
		while(true) {
			newPass = in.next();
			if(icaps.validatePassword(newPass)) {
				break;
			}
			else{
				System.out.println("Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character");
			}
		}
		
		ut.setUserId(user);
		ut.setLoginPassword(oldPass);
		ut.setNewPassword(newPass);
		icaps.changePassword(ut);

	}

	private static void trackService() throws CapgbankException {
		ServiceTracker st = new ServiceTracker();
		System.out.println("Enter your service id or Account Number:");
		String serviceId ="";
		while(true) {
			serviceId = in.next();
			if(icaps.validateServiceId(serviceId)) {
				break;
			}
			else{
				System.out.println("Enter valid digits");
			}
		}
		int servId = Integer.parseInt(serviceId);
		st.setserviceId(servId);
		String acno = serviceId;
		st.setaccountNumber(acno);

		try {
			List<ServiceTracker> mobilesList = new ArrayList<ServiceTracker>();
			mobilesList = icaps.trackService(st);

			if (mobilesList != null) {
				Iterator<ServiceTracker> i = mobilesList.iterator();
				System.out.println("Id    " + "Description  " + "A/c_no   "+ "Date     "+ " Status \n");
				while (i.hasNext()) {
					ServiceTracker obj = i.next();
					System.out.println(
							obj.getserviceId() + " " + obj.getserviceDescription() + " " + obj.getaccountNumber() + " "
									+ obj.getserviceRaisedDate() + " " + obj.getserviceStatus() + "\n");

				}
			} else {
				System.out.println("\nNo Service Requsets Found for the Given Details!!\n");
			}

		} catch (CapgbankException e) {

			System.out.println("Error  :" + e.getMessage());
		}

	}

	private static void requestChequeBook(String userid) throws CapgbankException {
		ServiceTracker st = new ServiceTracker();
		//System.out.println("Enter acccount number");
		String accountNo = icaps.getAccountNumber(userid);
		st.setaccountNumber(accountNo);
		in.nextLine();
		System.out.println("Enter Service Description");
		String servDesc = in.nextLine();

		st.setserviceDescription(servDesc);

		int requestId = icaps.requestChequeBook(st);
		System.out.println("Your can track your service request with the service Id: " + requestId);

	}

	private static void updateDetails(String username) throws CapgbankException {
		AccountMaster am = new AccountMaster();
		/*
		 * System.out.println("Enter your Account number");
		 */
		String acnumber = icaps.getAccountNumber(username);
		in.nextLine();
		System.out.println("Enter your new Address along with mobile number(city,mobileNo)");
		String address = in.nextLine();
		am.setAccountNumber(acnumber);
		am.setAddress(address);
		icaps.updateCustomerDetails(am);

	}

	private static void viewAllTransactions() {
		try {
			List<Transactions> mobilesList = new ArrayList<Transactions>();
			mobilesList = icaps.retriveTransactionDetails();

			if (mobilesList != null) {
				Iterator<Transactions> i = mobilesList.iterator();
				System.out.println("Id    " + "A/c no " + "Type   " + "Payee "
						+ "Amount   " + "Date     " + "Remarks"
						+ " Status \n");
				while (i.hasNext()) {
					Transactions obj = i.next();
					System.out.println(obj.getTransactionId() + " " + obj.getAccountNumber() + " "
							+ obj.getTransactionType() + " " + obj.getPayeeAccountId() + " "
							+ obj.getTransactionAmount() + " " + obj.getDateOfTransaction() + " "
							+ obj.getTransactionDescription() + " " + obj.getTransactionStatus() + "\n");

				}
			} else {
				System.out.println("\nNo Transactions Found!!\n");
			}

		} catch (CapgbankException e) {

			System.out.println("Error  :" + e.getMessage());
		}

	}

	private static void fundTransfer(String username) throws CapgbankException {

		Transactions trans = new Transactions();

		String transactionDescription;
		String transactionType = null;
		double transactionAmount;
		String accountNumber;
		String payeeAccountId;
		String transPassword;
		
		while(true) {
		System.out.println("Enter Payee Account Number");
		payeeAccountId = in.next();
		if(icaps.getAccountNumbers().contains(payeeAccountId)) {
			break;
		}
		else {
			System.out.println("InValid Account Number");
		}
		}
		System.out.println("Enter Amount");
		transactionAmount = in.nextDouble();
		
		  if((icaps.totalTransAmount(username)+transactionAmount)<=100000) {
		 
		accountNumber = icaps.getAccountNumber(username);
		String option = "0";
		while(!(option.equals("1")||option.equals("2"))) {
			System.out.println("\nEnter Transaction Type\n1.UPI\n2.IMFT");
			option = in.next();
			switch(option) {
			case "1":
				transactionType = "UPI";
				break;
			case "2":
				transactionType = "IMFT";
				break;
			default:
				System.out.println("Enter valid option");
			}
			
			
		}
		
		in.nextLine();
		System.out.println("Enter Transaction Description");
		transactionDescription = in.nextLine();
		System.out.println("\n"+transactionAmount+" will be deducted from the Account Number "+accountNumber+"\n");
		System.out.println("Enter Your Transaction Password To Continue");
		
		boolean start = true;
		while(start){
			transPassword = in.next();
			if(icaps.authFundTranfer(username, transPassword)){
				break;
			}
			else{
				System.out.println("Wrong Transaction Password\n");
				System.out.println("Enter your choice");
				System.out.println("1.Enter Correct Password\n2.Forget Password");
				String pass = in.next();
				switch(pass) {
				case "1":
					System.out.println("Enter Your Correct Password");
					break;
				case "2":
					
					System.out.println("Enter  Your Secret Q's:\n1.What Is Your Birth City ?"
							+ "\n2.Who Is Your Favorite Actor ?"
							+ "\n3.What Is Your Pet Name ?");
					String Qsoption = in.next();
					String scQs = "";
					switch(Qsoption) {
					case "1":
						scQs ="What Is Your Birth City ?";
						break;
					case "2":
						scQs ="Who Is Your Favorite Actor ?";
						break;
					case "3":
						scQs ="What Is Your Pet Name ?";
						break;
					
					}
					System.out.println("Enter Your Ans:");
					String ans =in.next();
					ans = ans.toLowerCase();
					scQs += ans;
					if(forgetPassword(username,scQs) !=null) {
						System.out.println(forgetPassword(username,scQs));
					}
					else {
						System.out.println("Wrong Q's or Ans, Contact Bank Officials for password reovery!!");
						start=false;
					}
					break;
				
				}
			}
		}
		
		if(start) {
		trans.setAccountNumber(accountNumber);
		trans.setPayeeAccountId(payeeAccountId);
		trans.setTransactionType(transactionType);
		trans.setTransactionAmount(transactionAmount);
		trans.setTransactionDescription(transactionDescription);

		icaps.fundTransfer(trans);
		}
		else {
			System.out.println("Transaction failed");
		}
		  }
		  else {
			  System.out.println("\nExceeds the Daily Transaction Amount Limit");
		  }

	}

	private static String forgetPassword(String username, String scQs) throws CapgbankException {
		String recoverdPass = icaps.getTransPass(username,scQs);
		if(recoverdPass != null) {
			return recoverdPass;
		}
		else {
			return null;
		}
		
		
	}

	private static void createNewAccount() throws CapgbankException {

		AccountMaster am = new AccountMaster();
		String accountType = null;
		double accountBalance;
		String accountHolderName;
		String email;
		String address;
		String panNumber;
		String option ="0";
		while(!(option.equals("1")||option.equals("2"))) {
			System.out.println("Enter Account Type:\n1.Savings Account\n2.Current Account");
			option = in.next();
			switch(option) {
			case "1":
				accountType = "Savings";
				break;
			case "2":
				accountType = "Current";
				break;
			default:
				System.out.println("Enter Valid Option");
			}
		}
		
		
		System.out.println("Enter Initial Account Balance");
		while(true) {
			String acbal = in.next();
			if(icaps.isDigit(acbal)) {
			accountBalance = Double.parseDouble(acbal);
			if(accountBalance>0) {
				break;
			}
			else {
				System.out.println("please enter balance greater than 0");
			}
		}
		}
		
		in.nextLine();
		System.out.println("Enter Account Holder Name");
		accountHolderName = in.nextLine();
		while(true) {
			System.out.println("Enter Account Holder Email address");
			email = in.next();
			if(icaps.validateMailId(email)) {
				break;
			}
			else {
				System.out.println("invalid email");
			}
		}
		

		in.nextLine();
		System.out.println("Enter Contact Info(city,mobileNo)");
		address = in.nextLine();
		System.out.println("Enter PAN Card Number");
		panNumber = in.next();

		am.setAccountType(accountType);
		am.setAccountBalance(accountBalance);
		am.setAccountHolderName(accountHolderName);
		am.setEmail(email);
		am.setAddress(address);
		am.setPanNumber(panNumber);

		icaps.createNewAccount(am);

	}

	private static void miniStatement(String accountNumber) {

		try {
			List<Transactions> transactionsList = new ArrayList<Transactions>();
			transactionsList = icaps.getMiniStatement(accountNumber);

			if (transactionsList != null) {
				Iterator<Transactions> i = transactionsList.iterator();
				System.out.println("Id    " + "A/c no " + "Type   " + "Payee "
						+ "Amount   " + "Date     " + "Remarks"
						+ " Status \n");
				while (i.hasNext()) {
					Transactions obj = i.next();
					System.out.println(obj.getTransactionId() + " " + obj.getAccountNumber() + " "
							+ obj.getTransactionType() + " " + obj.getPayeeAccountId() + " "
							+ obj.getTransactionAmount() + " " + obj.getDateOfTransaction() + " "
							+ obj.getTransactionDescription() + " " + obj.getTransactionStatus() + "\n");

				}
			} else {
				System.out.println("\nNo Transactions Found!!\n");
			}

		} catch (CapgbankException e) {

			System.out.println("Error  :" + e.getMessage());
		}

	}

}
